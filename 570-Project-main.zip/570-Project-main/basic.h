#Name(s): Frances Watson, [Inser Name], and [Insert Name]
#Description-
#This file will contain the function defintions for our basic.py and more.
