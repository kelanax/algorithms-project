#! /bin/bash

# Commands to install as requirements to executing this file
# pip3 install time
# pip3 install time
# pip3 install psutil

# Replace variables with the working directory 
python3 basic_3.py "$1" "$2"

