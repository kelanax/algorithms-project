#!/bin/bash

# Commands to install as requirements to executing this file
# pip3 install time
# pip3 install time
# pip3 install psutil

# Variables $1 and $2 will be replaced with the variables passed in by the user 
python3 efficient_3.py "$1" "$2"



